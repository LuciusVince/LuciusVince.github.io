<!DOCTYPE HTML>
<html>
  <head>
    <title>
      BMPLib-Test (&copy; Vincenzo Galati / TheRealVince)
    </title>
  </head>
  <body>
    <?php 
        include("./createBMP.php"); 

        // SimpleRGBTest
        function SimpleRGBTest() {
          $test123 = array();
          for($i = 0; $i < 33 * 100; $i++) { array_push($test123, [0xFF, 0x00, 0x00, 0x00]); }
          for($i = 0; $i < 34 * 100; $i++) { array_push($test123, [0x00, 0xFF, 0x00, 0x00]); }
          for($i = 0; $i < 33 * 100; $i++) { array_push($test123, [0x00, 0x00, 0xFF, 0x00]); }

          $result = CreateBitmap(100, 100, $test123);
          return $result;
        }

        $bmp = SimpleRGBTest(); 
        $b64bmp = base64_encode($bmp);
        echo "<img src='data:image/bmp;base64, " . $b64bmp . "' alt='beispiel' />"; 
    ?>
  </body>
</html>
