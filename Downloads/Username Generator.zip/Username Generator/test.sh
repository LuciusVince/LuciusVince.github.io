for x in $(seq 1 250); do php index.php; echo ""; done > usernameExamples.txt
