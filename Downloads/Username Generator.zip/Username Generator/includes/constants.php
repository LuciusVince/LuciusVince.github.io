<?php
const DBPATH_PREFIX = "./db/pre.txt";
const DBPATH_POSTFIX = "./db/post.txt";
?>
