<?php
include("./includes/constants.php");
$db_pre = explode("\n", file_get_contents(DBPATH_PREFIX));
$db_post = explode("\n", file_get_contents(DBPATH_POSTFIX));

$preIndex = rand(0, count($db_pre) -1);
$postIndex = rand(0, count($db_post) -1);

$prefix = $db_pre[$preIndex];
$suffix = $db_post[$postIndex];

echo "$prefix $suffix";

?>
