#!/usr/bin/env python3
# Author: TheRealVince
# 
# LICENSE: 
# Free for commercial and non-commercial reuse, no backlinking required,
# copyright is still hold by the owner (TheRealVince)
import sys
import requests


class JustDownload():
    # Constants
    DEFAULT_USERAGENT = "mozilla"

    def __init__(self, useragent = "mozilla"):
        if useragent != None:
            self.useragent = useragent
        else:
            self.useragent = self.DEFAULT_USERAGENT

    def ShowUsage(self):
        print("USAGE:")
        print("******")
        print(f"{sys.argv[0]} <url> [useragent = {self.useragent}] [outputFile]")
        print()
        print("If only the url has been specified, the result will be printed to stdout.")
        print("If the useragent stays empty, the default '{self.useragent}' will be used")
        print("If you call this function from python")
        print(" -> the html code will be returned instead of being printed to stdout.")
        print(" -> if you save the file 'None' will be returned." )
        print("    I assume here that one saves the file locally, because it was to big to fit into memory.")
        print("    As you have the file locally you can read it by other means.")
        print("")
        print("Example calls via CMD/Terminal:")
        print("*******************************")
        print("Get your WAN-IP:")
        print(f"> {sys.argv[0]} 'https://api.ipify.org/'")
        print("")
        print("Test a user-agent string and save the results to useragentDetails.json:")
        print("Note: If you leave the useragent empty, the default '{self.useragent}' will be used.")
        print(f"> {sys.argv[0]} 'https://api.redirect.li/v1/useragent' '' 'useragentDetails.json'")
        print(f"> {sys.argv[0]} 'https://api.redirect.li/v1/useragent' 'Mozilla/5.0 (compatible; Googlebot/2.1' 'useragentDetails.json'")
        print("")
        print("Example calls via Python:")
        print("*******************************")
        print(">>> from justDownload import *")
        print(">>> googleHtml = Download('https://www.google.com')")
        print(">>> DownloadFile('https://upload.wikimedia.org/wikipedia/commons/b/b7/Flag_of_Europe.svg', 'EU_Flag.svg')")
        print("")


    def ParseArg(self, argIndex, defaultVal = None):
        if len(sys.argv) > argIndex and sys.argv[argIndex] != None and sys.argv[argIndex] != "":
            return sys.argv[argIndex]
        else:
            return defaultVal


    def Start(self, url = None, outputFile = None):
        
        # Script is executed directly, so use sys.argv 
        # instead of above declared parameters
        if __name__ == '__main__':
            url = self.ParseArg(1)
            useragent = self.ParseArg(2, self.useragent)
            outputFile = self.ParseArg(3)
        else:
            useragent = self.useragent

        # Show help
        if not url or "-h" in sys.argv or "--help" in sys.argv:
            self.ShowUsage() # quit after that
            quit()

        # Get the html code (or whatever...)
        headers = {'User-Agent': useragent}
        myRequest = requests.get(url, headers = headers)
        myRequest.encoding = myRequest.apparent_encoding # libChardet provides the right encoding, so we use that

        # Write to stdout or outputfile
        if not outputFile:
          # if executed via commandline,
          # output html content directly to stdout
          if myRequest.apparent_encoding != None:
            result = str(myRequest.content, encoding = myRequest.apparent_encoding)
          else:
            result = myRequest.content

          if __name__ == '__main__':
              print(result)

          return result
        else:
          #with open(outputFile, 'wb', encoding = myRequest.apparent_encoding) as fHandle:
          with open(outputFile, 'wb') as fHandle:
              fHandle.write(myRequest.content)
              return None

# Wrapper for a function call.
# Downloads and returns the content of an url
def Download(url = None, useragent = None):
    return JustDownload(useragent).Start(url)

# Downloads a file to your local storage.
def DownloadFile(url = None, savepath = None, useragent = None):
    JustDownload(useragent).Start(url, savepath)
    

# Without parameters, JustDownload defaults to use sys.argv
# 
# As the script is called directly,
# we leave the function call without parameters
# so that the script knows, that is has to pull 
# the parameters from sys.argv

if __name__ == '__main__':
    JustDownload().Start() 

# Show help after Import
#print("from justDownload import *")
#print(">>> googleHtml = Download('https://www.google.com')")
#print(">>> DownloadFile('https://upload.wikimedia.org/wikipedia/commons/b/b7/Flag_of_Europe.svg', 'EU_Flag.svg')")
