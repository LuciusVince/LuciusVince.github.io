Copyright by Vincenzo Galati / TheRealVince
LICENSE: GPL

Bookmanager Light Description:
******************************
Bookmanager Light is an MySQL-based book management system.
It is able to register and download metadata from books by their respective ISBN.
The "Light" in "Bookmanager Light" means, that you don't need to store the data locally,
altough you can if you want.

Start:
1. To start navigate to either the "debug" or "release" directory and start "BookManager.exe".
2. If this is your first launch, you will be prompted to setup an mysql-connection.
3. After you have configured your mysql connection successfully you can start registering books.
4. To register books via ISBN navigate to textbox to the upper right corner, enter your ISBN and press [Enter].

Minumum system requirements
***************************
OS: Windows 10
.NET Framework 4.6.1
Access to an mysql server: 	You can easily host your own locally via xampp 
				for more Information, visit: 
				https://en.wikipedia.org/wiki/Xampp 
				https://apachefriends.org