<?php
include('./includes/libs/TheRealVince.SimpleBitmapCreatorLib/createBMP.php');
include('./includes/api.php');

header('Content-type: image/bmp');
header('Content-Disposition: inline; filename="Avatar.bmp"');
CreateAvatar(256, 256, 40, 6); // Erzeugt ein BMP. NICHTS ANDERES! Auch wenn o.g. Content-Types geaendert werden. ES BLEIBT EIN BMP!
?>

