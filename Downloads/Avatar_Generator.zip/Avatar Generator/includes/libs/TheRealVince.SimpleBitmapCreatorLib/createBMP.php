<?php
function CreateBytes(...$numbers) {
  $retVal = "";
  foreach($numbers as $n) {
    $retVal .= chr($n);
  }

  return $retVal;
}

// Unpack lief buggy, deswegen eigene Implementierung
function CreateInt32($number) {
  $rest = $number;

  $b1 = $rest % 256;
  $rest = intdiv($rest, 256);

  $b2 = $rest % 256;
  $rest = intdiv($rest, 256);

  $b3 = $rest % 256;
  $rest = intdiv($rest, 256);

  $b4 = $rest;

  return chr($b1) . chr($b2) . chr($b3) . chr($b4);
}

// RGBA-Bytes ist ein Array aus RGBA-Arrays [[R1,G1,B1,A1], [R2,G2,B2,A2], [Rn, Gn, Bn, An], ...]
// ------------------------------------------------------------------------------------------------
// Die uebergebenen RGBA-Byte-Matrix muss, um wie vom Anwender ( / Entwickler) vorgesehen ausgegeben zu werden,
// nochmal invertiert werden. Sonst wird die Grafik auf dem Kopf dargestellt.
function CreateBitmap($width, $height, $rgbaBytes_Reversed, $fallbackColor = [0xFF, 0xFF, 0xFF, 0x00]) {
  $bmp = "";
  $rgbaBytes = array_reverse($rgbaBytes_Reversed);

  // Header Part I: BMP Header
  $bmpHeader_TotalHeaderSize = 14 + 40; // 14 = Part I, 40 = Part II
  $bmpHeaderI_BitmapDataSize = $width * $height * 4; // width * height * RGBA

  $bmp .= CreateBytes(0x42, 0x4D);
  $bmp .= CreateInt32($bmpHeader_TotalHeaderSize + $bmpHeaderI_BitmapDataSize);
  $bmp .= CreateBytes(0x00, 0x00); // Lt. Formatbeschreibung: Unused, Application Specific I
  $bmp .= CreateBytes(0x00, 0x00); // Lt. Formatbeschreibung: Unused, Application Specific II
  $bmp .= CreateInt32($bmpHeader_TotalHeaderSize);

  # Header Part II: DIB Header
  $bmp .= CreateBytes(0x28, 0x00, 0x00, 0x00); // 0x28 = 40 Bytes, statische Laenge des DIB-Headers
  $bmp .= CreateInt32($width);
  $bmp .= CreateInt32($height);
  $bmp .= CreateBytes(0x01, 0x00); // Anzahl der color planes
  $bmp .= CreateBytes(0x20, 0x00); // Farbtiefe (0x20 = 32 Bit)
  $bmp .= CreateInt32(0x00);       // Keine Kompression
  $bmp .= CreateInt32($bmpHeaderI_BitmapDataSize);
  $bmp .= CreateBytes(0x13, 0x0B, 0x00, 0x00); // 72 DPI (72DPI * 39.3701 = 2834.6472 bzw. 0x130B 0000)
  $bmp .= CreateBytes(0x13, 0x0B, 0x00, 0x00); // 72 DPI
  $bmp .= CreateBytes(0x00, 0x00, 0x00, 0x00); // Anzahl der Farben in der Farbpalette
  $bmp .= CreateBytes(0x00, 0x00, 0x00, 0x00); // 0 Bedeutet alle Farben sind wichtig

  $lenRgbaBytes = count($rgbaBytes);
  $index = 0;
  
  for($i = 0; $i < $width; $i++) {
    for($j = 0; $j < $height; $j++) {
      //if($index + 3 < $lenRgbaBytes) {
      if($index < $lenRgbaBytes) {
          $b1 = $rgbaBytes[$index][0];
          $b2 = $rgbaBytes[$index][1];
          $b3 = $rgbaBytes[$index][2];
          $b4 = $rgbaBytes[$index][3];


          // Die Farben hier sind bei der originalen Matrix ARGB
          // Nachdem die Matrix zur korrekten Darstellung invertiert wurde, ist es BGRA
          // Wir wollen aber RGBA, deshalb ist die Reihenfolge unterschiedlich (3,2,1,4 statt 1,2,3,4)
          // $bmp .= CreateBytes($b1, $b2, $b3, $b4);
          $bmp .= CreateBytes($b3, $b2, $b1, $b4);

          $index += 1;
      }
      else {
        // Wie oben: RGBA statt BGRA/ARGB (2,1,0,3 statt 0,1,2,3)
        // $bmp .= CreateBytes($fallbackColor[0], $fallbackColor[1], $fallbackColor[2], $fallbackColor[3]);
        $bmp .= CreateBytes($fallbackColor[2], $fallbackColor[1], $fallbackColor[0], $fallbackColor[3]);
      }
    }

      // Anmerkung:
      // Bei RGB-Werten waere an dieser Stelle ein Padding um die 4-Byte-Struktur aufzufuellen notwendig,
      // da wir aber auf RGBA setzen entfaellt das hier.
  }
  


  

  return $bmp;
}
?>
