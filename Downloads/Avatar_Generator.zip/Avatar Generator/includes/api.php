<?php
// Malt eine Form via FG-Color (ForeGround-Color)
// Hintergrund wird via BG-Color (BackGround-Color) gesetzt
// Die Breite wird benoetigt, um die korrekte Anzahl an Pixeln pro Zeile zu ermitteln
// --
// Aufbau eines Muster-Elementes TL;DR: Weihnachtsbaumlogik
//    *
//   ***    <= 2te Reihe besteht aus 3 Sternen statt 2, Ab der 2ten Reihe kommen immer 2 Pixel dazu
//  *****
// *******
function DrawFormRow($fgArr, $bgArr, $totalWidth, $anzahlZeilenProForm = 45, $anzahlFormen = 20) {
  $anzahlPixel = $totalWidth * $anzahlZeilenProForm;
  $result = [];
  
  // Hintergrund malen
  for($i = 0; $i < $anzahlPixel; $i++) {
    array_push($result, $bgArr);
  }

  // Vordergrund malen
  for($i = 0; $i < intdiv($anzahlZeilenProForm, 2); $i++) {
    $anzahlPunkteProForm = ($i * 2) + 1;
    $abstand = $totalWidth / $anzahlFormen;
    $positionX = intdiv($abstand, 2);
    $aktuelleZeile = $i * $totalWidth;

    for($j = 0; $j < $anzahlFormen; $j++) {
      $aktuelleSpalte = $j * $abstand;

      for($dot_i = 0; $dot_i < $anzahlPunkteProForm; $dot_i++) {
        //$aktuellePosition = ($aktuelleSpalte) + (($anzahlPunkteProForm -1) / 2) + $dot_i + $aktuelleZeile;
        $aktuellePosition =  $aktuelleSpalte + ($dot_i - (($anzahlPunkteProForm -1) / 2)) + $aktuelleZeile;
        if($aktuellePosition >= 0 && $aktuellePosition < count($result)) {
          $result[$aktuellePosition] = $fgArr;
        }

          // spiegeln
          // durch 2 teilen und dann mit 2 mal nehmen, da Integer-Division. Wir arbeiten mit
          // der Haelfte, ohne diese redundant-aussehende Berechnung wuerde es bei ungeraden Zahlen jedoch zu Fehlern kommen.
          // Kann man sicher schoener machen, im Zweifelsfall refaktorieren
          $aktuelleZeileGespiegelt = ($totalWidth * $anzahlZeilenProForm) - $aktuelleZeile - ($totalWidth * 2); 
          $aktuellePositionGespiegelt =  $aktuelleSpalte + ($dot_i - (($anzahlPunkteProForm -1) / 2)) + $aktuelleZeileGespiegelt;
          if($aktuellePositionGespiegelt >= 0 && $aktuellePositionGespiegelt < count($result)) {
            $result[$aktuellePositionGespiegelt] = $fgArr;
          }
        
      }

      $positionX += $abstand;
    }
    
  }

  return $result;
}

function CalcColorDifference($color1, $color2, $percent) {
  return intval($color1 + $percent * ($color2 - $color1));
}

function CalcGradient($colorArr1, $colorArr2, $percent) {
  $r = CalcColorDifference($colorArr1[0], $colorArr2[0], $percent);
  $g = CalcColorDifference($colorArr1[1], $colorArr2[1], $percent);
  $b = CalcColorDifference($colorArr1[2], $colorArr2[2], $percent);
  $a = CalcColorDifference($colorArr1[3], $colorArr2[3], $percent);

  return [$r, $g, $b, $a];
}

function DrawPatternWithGradient($startColor, $endColor, $width, $height, $anzahlZeilenProForm, $anzahlFormen) {
  
  $rowArr = [];

  $anzahlMusterZeilen = intdiv($height, $anzahlZeilenProForm) + 1;
  for($i = 0; $i < $anzahlMusterZeilen; $i++) {
    $prozent = 1 / $anzahlMusterZeilen * $i;
    $fg = CalcGradient($startColor, $endColor, $prozent);
    
    $row = DrawFormRow($fg, [0x10, 0x10, 0x10, 0x00], $width, $anzahlZeilenProForm, $anzahlFormen);
    array_push($rowArr, $row);
  }


  $result = [];
  for($i = 0; $i < count($rowArr); $i++) {
    for($j = 0; $j < count($rowArr[$i]); $j++) {
      array_push($result, $rowArr[$i][$j]);
    }
  }

  return $result;
}

function GetRandomColor() {
  return [rand(0, 0xFF), rand(0, 0xFF), rand(0, 0xFF), 0x00];
}

function CreateAvatar($width = 720, $height = 720, $anzahlZeilenProForm = 10, $anzahlFormen = 10) {
  $bitmapArr = array();

  for($i = 0; $i < $width * $height; $i++) {
    array_push($bitmapArr, [0x00, 0x00, 0xFF, 0x00]);
  }

  $gradientPatternMatrix = DrawPatternWithGradient(GetRandomColor(), 
                                                   GetRandomColor(), 
                                                  $width, $height, 
                                                  rand($anzahlZeilenProForm, $anzahlZeilenProForm + intdiv($anzahlZeilenProForm, 10)), 
                                                  rand($anzahlFormen, $anzahlFormen + intdiv($anzahlFormen, 3)));
  for($i = 0; $i < count($bitmapArr) && $i <count($gradientPatternMatrix); $i++) {
     $bitmapArr[$i] = $gradientPatternMatrix[$i];
  }

  $result = CreateBitmap($width, $height, $bitmapArr);
  echo $result;
}
?>
