#!/bin/bash
url="$1"
outputNameHtml="$2.html" # Falls nicht gesetzt, weiter unten automatisch ermittelt
useragent="mozilla"

echo " ____  _     ___ ____  _____ ____  _   _    _    ____  _____   _   _ _____ _____   ____                      _                 _           "
echo "/ ___|| |   |_ _|  _ \| ____/ ___|| | | |  / \  |  _ \| ____| | \ | | ____|_   _| |  _ \  _____      ___ __ | | ___   ____  __| | ___ _ __ "
echo "\___ \| |    | || | | |  _| \___ \| |_| | / _ \ | |_) |  _|   |  \| |  _|   | |   | | | |/ _ \ \ /\ / / '_ \| |/ _ \ / _  |/ __ |/ _ \  __|"
echo " ___) | |___ | || |_| | |___ ___) |  _  |/ ___ \|  _ <| |___ _| |\  | |___  | |   | |_| | (_) \ V  V /| | | | | (_) | (_| | (_| |  __/ |   "
echo "|____/|_____|___|____/|_____|____/|_| |_/_/   \_\_| \_\_____(_)_| \_|_____| |_|   |____/ \___/ \_/\_/ |_| |_|_|\___/ \__,_|\__,_|\___|_|   "
echo "by TheRealVince"
echo "                                                                                                                                           "


if [[ -z "$1" ]]; then
  echo "USAGE:"
  echo "$0 <slideshare.net-url> [outputName (automatisch ermittelt)].pdf"
  exit
fi

function CreateB64ImageTag
{
     imagePath="$1"
     suffix=$(basename $imagePath | rev | cut -d'.' -f1 | rev)
     b64=$(base64 "$1" |  tr -d $'\n')
     result="<tr><td><img src=\"data:image/$suffix;base64,$b64\"></td></tr>"

     echo $result
}

# AusgabeOrdner und Laufvariablen
outputDir="./tmp"
tmpHtml="$outputDir/tmp.html"
mkdir -p "$outputDir"
iUnifier=1000
i=1

# Html herunterladen
echo "Url: $url"
wget --user-agent="$useragent" -qO - "$url" > "$tmpHtml"

# Titel ermitteln
title=$(grep -m 1 "<title>" "$tmpHtml" | cut -d'>' -f2 | cut -d'<' -f1 | grep -Po '[a-zA-Z0-9 ]+' | tr -d $'\n')
echo "Title: $title"
if [[ -z "$2" ]]; then
  outputNameHtml="$title.html"
fi

outputNamePDF=$(echo $outputNameHtml | sed -E "s|\.html$|\.pdf|g")
echo "OutputName: $outputNamePDF"

if [[ -f "$outputNamePDF" ]]; then
  echo ""
  echo "Skippe \"$outputNamePDF\", da bereits vorhanden."
  exit
fi

# Maximale Anzahl der Seiten ermitteln
maxPage=$(grep -Po '<span id="total-slides" class="j-total-slides">[0-9]+</span>' "$tmpHtml" | grep -Po '[0-9]+')

# Bilder runterladen und Namen der Bilder AusgabeBefehl uebergeben
echo "" # leere Zeile aus Formatierungsgruenden
>"$outputNameHtml" # Ausgabe-Datei erzeugen
echo '<table border="0">' >> "$outputNameHtml"
#for picUrl in $(grep -Po 'data-normal="(.+?)"' "$tmpHtml" | cut -d'"' -f2); do
for picUrl in $(grep -Po 'href="https://image.slidesharecdn.com/(.+?)"' "$tmpHtml" | cut -d'"' -f2); do
  echo "Lade $i von $maxPage ($picUrl)"
  suffix=$(basename "$picUrl" | cut -d '?' -f1 | rev | cut -d '.' -f1 | rev)
  savePath="$outputDir/$(($i + $iUnifier)).$suffix"

  wget --user-agent="$useragent" -qO "$savePath" "$picUrl"
  CreateB64ImageTag "$savePath" >> "$outputNameHtml"


  i=$(($i + 1))
done
echo '</table>' >> "$outputNameHtml"

# Haeng die Beschreibung dran
cat "$tmpHtml" | tr -d $'\n' | grep -Po '<ol(.+?)</ol>' | tr -d '|' | sed "s|•|<br>•|g" | sed "s||<br>|g" | sed "s||<br> - |g" >> "$outputNameHtml"

# 
echo "Converting to pdf ($outputNameHtml => $outputNamePDF)"
wkhtmltopdf "$outputNameHtml" "$outputNamePDF"

# CleanUp
rm -f "$outputNameHtml"
rm -rf "$outputDir"
